﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
namespace UDPChatSimple
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;       
        }
        private UdpClient udpLocal = null;
        private IPEndPoint ipremote;
        Thread getThread = null;
        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        private void openinput(bool state)
        {
            this.btnGui.Enabled = !state;
            this.txtIPR.ReadOnly = !state;
            this.txtPortL.ReadOnly = !state;
            this.txtPortR.ReadOnly = !state;
            this.btnKN.Enabled = state;
        }
        private void NhanDL()
        {
            try
            {
                
                while (true)
                {
                    byte[] data = new byte[1024];
                    IPEndPoint ipe = new IPEndPoint(IPAddress.Any, int.Parse(txtPortL.Text.Trim()));
                    data = udpLocal.Receive(ref ipe);
                    if (!chkPrivate.Checked)
                    {                       
                        string s = Encoding.UTF8.GetString(data, 0, data.Length);
                        rtxMsg.Text += "Received: " + s + "\r\n";                       
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void btnKN_Click(object sender, EventArgs e)
        {
            try
            {
                udpLocal = new UdpClient(int.Parse(txtPortL.Text.Trim()),AddressFamily.InterNetwork);                
                ipremote = new IPEndPoint(IPAddress.Parse(txtIPR.Text.Trim()), int.Parse(txtPortR.Text.Trim()));
                openinput(false);
                getThread = new Thread(new ThreadStart(NhanDL));
                getThread.IsBackground = true;
                getThread.Start();
            }
            catch (Exception ex)
            {
                openinput(true);
                MessageBox.Show(ex.ToString()); 
            }
        }  
        private void btnGui_Click(object sender, EventArgs e)
        {
            try
            {
            byte[] data = new byte[1024];
            data = Encoding.UTF8.GetBytes(txtMsg.Text);
            udpLocal.Send(data,data.Length,ipremote);
            rtxMsg.Text += "Sent: " + txtMsg.Text + "\r\n";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString()); 
            }
        }

    }
}
