﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChatApp
{
    public partial class Server : Form
    {
        TcpListener Listener;
        int portN;
        String rootDir="D:/";
        public Server()
        {
            InitializeComponent();
        }
        private delegate void dlgAddInfo(string str);
        private void AddInfo(string str)
        {
            if (this.rtxInfo.InvokeRequired)
            { this.Invoke(new dlgAddInfo(AddInfo), str); }
            else
            { this.rtxInfo.AppendText(str+"\n\r"); }
        }
        private void RegJob(String[] request, StreamWriter sw)
        {
            string fileName = request[1];
            fileName = rootDir + "/" + fileName.Trim()+".txt";
            String s = "Lỗi. Tài khoản đã tồn tại.";
           
            if (!File.Exists(fileName))
            {               
                File.WriteAllText(fileName, request[2]+"\n\r");
                s = "Tạo tài khoản thành công";
            }

            sw.WriteLine(s);
            sw.Flush();
        }
        private void SenJob(String[] request, StreamWriter sw)
        {
            string fileName = request[1];
            fileName = rootDir + "/" + fileName.Trim() + ".txt";
            String s = "Lỗi. Tài khoản không tồn tại.";
          
            if (File.Exists(fileName))
            {
                File.AppendAllText(fileName, request[2] + "\n\r");             
                s = "Đã lưu tin nhắn";
            }
            
            sw.WriteLine(s);
            sw.Flush();
        }
        private void GetJob(String[] request, StreamWriter sw)
        {
            string fileName = request[1];
            fileName = rootDir + "/" + fileName.Trim() + ".txt";
            String s = "Lỗi. Tài khoản không tồn tại.";
           
            if (File.Exists(fileName))
            {
                String[] lines=File.ReadAllLines(fileName);
                if (request.Length>2&&request[2] != lines[0])
                    s = "Lỗi. Sai Mật Khẩu.";
                else
                {
                    File.Delete(fileName);
                    File.WriteAllText(fileName, request[2] + "\n\r");
                    lines = lines.Skip(1).ToArray();
                    s = String.Join(" ", lines);
                }
            }
           
            sw.WriteLine(s);
            sw.Flush();
        }
        private void UndefinedCommand(String[] request, StreamWriter sw)
        {
            String s = "Lỗi. Lệnh không tồn tại:"+ request[0];
            byte[] data = new byte[s.Length];
            sw.Write(s, 0, s.Length);
            sw.Flush();
        }
        private void ThreadProc(object obj)
        {
            try { 
            var client = (TcpClient)obj;
            StreamReader sr = new StreamReader(client.GetStream());
            StreamWriter sw = new StreamWriter(client.GetStream());
            sw.WriteLine("Chao mung ket noi toi MyFolder");
            sw.Flush();
            while (true)
            {
                string raw = sr.ReadLine();
                string[] request = raw.Split(' ');
                AddInfo("Client Command:"+raw);
                string command = "";
                if (request.Length != 0)
                    command = request[0];
                switch (command.ToUpper().Trim())
                {
                    case "REG"://đăng ký
                        {
                            RegJob(request,sw);
                            break;
                        }
                    case "SEN"://gửi tin
                        {
                            SenJob(request, sw);
                            break;
                        }
                    case "GET"://nhận tin tin
                        {
                            GetJob(request, sw);
                            break;
                        }
                    default:
                        {
                            UndefinedCommand(request, sw);
                            break;
                        }
                }
            }
        }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
}
        public void ListenerThread()
        {            
            Listener = null;
            try
            {
                Listener = new TcpListener(IPAddress.Any, portN);
                Listener.Start();
                while (true)
                {
                    TcpClient client = null;
                    NetworkStream netstream = null;
                    if (Listener.Pending())
                    {
                        client = Listener.AcceptTcpClient();
                        netstream = client.GetStream();
                        AddInfo("Kết nối với Client.");
                        ThreadPool.QueueUserWorkItem(ThreadProc, client);
                       // netstream.Close();
                       // client.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }            
        }
        private void btnStart_Click(object sender, EventArgs e)
        {
            Thread thdListener = new Thread(new ThreadStart(ListenerThread));
            portN = int.Parse(txtPort.Text);
            thdListener.Start();
            thdListener.IsBackground=true;
            AddInfo("Server đã khởi động");

        }
    }
}
